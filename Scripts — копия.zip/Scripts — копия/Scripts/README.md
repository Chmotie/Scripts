# Scripts
> Различные скрипты в одном скрипте.
Во вопросам пишите мне в ВКонтакте: vk.com/chmotie

Функции:
1. Сканер портов
2. Рейд бот
3. Деанон функции
4. Vk Скрипты

#Устанока

1. Установим зависимости:

   Необходим Python3:
   
       pip3 install socket
       pip3 install vk_api
       pip3 install requests
       pip3 install urllib
       pip3 install colorama
       pip3 install init

2. Установим Git:

   Git необходим для того, что бы скопировать скрипт.
  
   Для Linux:

         sudo apt-get install git
      
   Для Termux:

         pkg install git

3. Гит клоним скрипт:

         git clone https://github.com/Chmotie/Scripts
 
4. Запускаем скрипт:

   Для Linux:
   
         sudo python3 main.py
      
      
   Для Termux:
   
         python3 main.py


