from vkwave.bots import *
from command import (
    social_router,
    system_router,
    delete_router,
    auto_router
)
from Utils.middleware import Middleware
from rich.console import Console
import json

bot = SimpleLongPollUserBot(tokens='37d942c4cada5ce89f0e7fd931704162ee73a85b2796f472f6327a04c5b388c6eca5171d60e4019808457')
console = Console()

bot.add_middleware(Middleware())


console.log(f"[bold green]Загрузка команд..")
bot.dispatcher.add_router(system_router)
console.log(f"[bold red] Системные команды загружены..")
bot.dispatcher.add_router(social_router)
console.log(f"[bold red] Социальные команды загружены..")
bot.dispatcher.add_router(delete_router)
console.log(f"[bold red] Удаления команды загружены..")
bot.dispatcher.add_router(auto_router)
console.log(f"[bold red] Команды авто-ответчика загружены..")

bot.run_forever()
