from vkwave.types.user_events import EventId
from vkwave.bots import (
    DefaultRouter,
    UserEvent,
    FromMeFilter,
    MessageFromConversationTypeFilter,
    TextStartswithFilter,
    TextFilter,
    SimpleLongPollBot,
    ReplyMessageFilter,
    FwdMessagesFilter,
    EventTypeFilter
)
import json
import asyncio
from vkwave.api.methods._error import APIError

bot = SimpleLongPollBot(tokens='37d942c4cada5ce89f0e7fd931704162ee73a85b2796f472f6327a04c5b388c6eca5171d60e4019808457',group_id=200042823)
auto_router = DefaultRouter()

@auto_router.registrar.with_decorator(
    TextStartswithFilter(['да']),
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id

    (await bot.api_context.messages.send(message = f'Пизда',
                                         peer_id = peer_id,
                                         random_id = 0))
# @auto_router.registrar.with_decorator(
#     TextStartswithFilter(['hello']),
# )
#
# async def panos(event:UserEvent):
#     peer_id = event.object.object.peer_id
#
#     print(event.object.object.text)