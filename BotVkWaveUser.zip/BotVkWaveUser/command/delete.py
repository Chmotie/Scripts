from vkwave.types.user_events import EventId
import sqlite3
from vkwave.bots import (
    DefaultRouter,
    UserEvent,
    FromMeFilter,
    MessageFromConversationTypeFilter,
    TextStartswithFilter,
    TextFilter,
    SimpleLongPollBot,
    ReplyMessageFilter,
    FwdMessagesFilter,
    EventTypeFilter
)
db = sqlite3.connect("base.db")
sql = db.cursor()

to_delete = []

sql.execute("""CREATE TABLE IF NOT EXISTS ignorlist(
   id INT
)""")
db.commit()

bot = SimpleLongPollBot(tokens='b8410815399fbaa3349e3caf5da19d7880144336d77d60f22927848bfd561dae9aae2f160f1bf4fb9bb38',group_id=200042823)
delete_router = DefaultRouter()

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.add']),
    ReplyMessageFilter()
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]
    sql.execute(f"INSERT INTO ignorlist(id) VALUES({msg_from_id})")
    db.commit()
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'[💣] [id{msg_from_id}|Пользователь] Был добавлен в ИГНОР-ЛИСТ.',
                                       message_id=msg_id, keep_forward_messages=1))

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.add']),
    bot.args_filter(args_count=1)
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id

    msg_id = event.object.object.message_id
    print(event["args"][0])
    events = event["args"][0]
    sql.execute(f"INSERT INTO ignorlist(id) VALUES({events})")
    db.commit()
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'[💣] [id{events}|Пользователь] Был добавлен в ИГНОР-ЛИСТ.',
                                       message_id=msg_id, keep_forward_messages=1))

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.remove']),
    ReplyMessageFilter()
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]
    sql.execute(f"DELETE from ignorlist WHERE id={msg_from_id}")
    db.commit()
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'[💣] [id{msg_from_id}|Пользователь] Был удален из ИГНОР-ЛИСТА.',
                                       message_id=msg_id, keep_forward_messages=1))\

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.remove']),
    bot.args_filter(args_count=1)
)

async def panos(event:UserEvent):
    events = event["args"][0]
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    sql.execute(f"DELETE from ignorlist WHERE id={events}")
    db.commit()
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'[💣] [id{events}|Пользователь] Был удален из ИГНОР-ЛИСТА.',
                                       message_id=msg_id, keep_forward_messages=1))

@delete_router.registrar.with_decorator(
    MessageFromConversationTypeFilter(from_what = 'from_chat'),
)

async def panes(event:UserEvent):
    db = sqlite3.connect("base.db")
    sql = db.cursor()
    peer_id = event.object.object.peer_id
    sql.execute("SELECT * FROM ignorlist")
    ignor = sql.fetchall()
    ignored = list(ignor)
    for i in range(len(ignored)):
        print(ignored[i][0])

        msgs = (await event.api_ctx.messages.get_history(peer_id=peer_id,
                                                count=50)).response.items
        for msg in msgs:
            if msg.from_id == ignored[i][0]:
                to_delete.append(msg.id)
                print(to_delete)
                try:
                    await event.api_ctx.messages.delete(message_ids=to_delete,
                                                delete_for_all=1)
                except:
                      await event.api_ctx.messages.delete(message_ids=to_delete)
                to_delete.clear()




@delete_router.registrar.with_decorator(
    TextFilter(['.e']),
)

async def panos(event:UserEvent):
    gif = (await event.api_ctx.gifts.get(user_id=483664051,count=5)).response.items
    for i in gif:
       print(i.from_id)

